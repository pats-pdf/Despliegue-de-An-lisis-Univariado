import streamlit as st
import pandas as pd
import plotly.express as px
from pathlib import Path

# Configuración
st.set_page_config(
    page_title="GAC | Bitácora de Piso",
    page_icon="🚗",
    layout="wide"
)

CARPETA_BASE = Path(__file__).resolve().parent.parent


@st.cache_data
def load_data():
    df = pd.read_csv(
        CARPETA_BASE / "Bitacora_Piso_Limpia.csv"
    )

    df.columns = df.columns.str.strip()

    df = df.rename(columns={
        "PDM": "Prueba de manejo",
        "Inter Gerente": "Intervención del gerente"
    })

    variables = [
        "Estatus Lead",
        "Prueba de manejo",
        "Intervención del gerente"
    ]

    for variable in variables:
        df[variable] = (
            df[variable]
            .astype("string")
            .str.strip()
            .replace("", pd.NA)
            .fillna("No registrado")
        )

    # Unificar variantes de Sí y No
    for variable in [
        "Prueba de manejo",
        "Intervención del gerente"
    ]:
        normalizado = df[variable].str.casefold()

        df.loc[normalizado.isin(["sí", "si"]), variable] = "Sí"
        df.loc[normalizado.eq("no"), variable] = "No"

    return df


df = load_data()

# Barra lateral y filtro
st.sidebar.title("🚗 GAC | Bitácora de Piso")

opciones_estatus = sorted(
    df["Estatus Lead"].unique().tolist()
)

estatus_seleccionados = st.sidebar.multiselect(
    "Filtrar por estatus",
    options=opciones_estatus,
    default=opciones_estatus,
    key="bitacora_filtro_estatus"
)

df_filtrado = df[
    df["Estatus Lead"].isin(estatus_seleccionados)
].copy()

# Encabezado
col_logo, col_titulo = st.columns([1, 5])

with col_logo:
    st.image(
        str(CARPETA_BASE / "logo_gac.png"),
        width=150
    )

with col_titulo:
    st.title("Bitácora de Piso")
    st.caption(
        "GAC · Análisis de prospectos y atención comercial"
    )

st.markdown(
    """
    <div style="
        height:4px;
        background:#D71920;
        border-radius:4px;
        margin-bottom:20px;
    "></div>
    """,
    unsafe_allow_html=True
)

# Diseño de tarjetas
st.markdown(
    """
    <style>
    .gac-tarjeta {
        background: rgba(117, 0, 21, 0.22);
        border: 1px solid rgba(215, 25, 32, 0.25);
        border-radius: 16px;
        padding: 20px 24px;
        margin-bottom: 20px;
        min-height: 165px;
        box-sizing: border-box;
    }

    .gac-titulo {
        color: #F3DDE1;
        font-size: 15px;
        margin-bottom: 10px;
    }

    .gac-numero {
        color: #FFFFFF;
        font-size: 38px;
        font-weight: 700;
        line-height: 1.2;
    }

    .gac-insignia {
        display: inline-block;
        margin-top: 10px;
        padding: 4px 10px;
        border-radius: 20px;
        background: rgba(255,255,255,0.12);
        color: #FFFFFF;
        font-size: 12px;
    }

    .gac-detalle {
        color: #CBD5E1;
        font-size: 12px;
        margin-top: 8px;
    }
    </style>
    """,
    unsafe_allow_html=True
)

if df_filtrado.empty:
    st.warning("Selecciona al menos un estatus con registros.")
    st.stop()

# Indicadores
total = len(df_filtrado)
porcentaje_total = total / len(df) * 100

cantidad_pdm = int(
    df_filtrado["Prueba de manejo"].eq("Sí").sum()
)

cantidad_gerente = int(
    df_filtrado["Intervención del gerente"].eq("Sí").sum()
)

porcentaje_pdm = cantidad_pdm / total * 100
porcentaje_gerente = cantidad_gerente / total * 100

pdm_base = (
    df["Prueba de manejo"].eq("Sí").mean() * 100
)

gerente_base = (
    df["Intervención del gerente"].eq("Sí").mean() * 100
)


# Comparación descriptiva con toda la base
def crear_comparacion(porcentaje, referencia):
    diferencia = round(porcentaje - referencia, 1)

    if diferencia > 0:
        texto = f"↑ {diferencia:.1f} pp frente a la base"
    elif diferencia < 0:
        texto = f"↓ {abs(diferencia):.1f} pp frente a la base"
    else:
        texto = "Sin diferencia frente a la base"

    return (
        '<div class="gac-insignia">'
        f"{texto}</div>"
    )


comparacion_pdm = crear_comparacion(
    porcentaje_pdm,
    pdm_base
)

comparacion_gerente = crear_comparacion(
    porcentaje_gerente,
    gerente_base
)

# Tres tarjetas
tarjeta_1, tarjeta_2, tarjeta_3 = st.columns(3)

with tarjeta_1:
    st.markdown(
        f"""
        <div class="gac-tarjeta">
            <div class="gac-titulo">📋 Registros seleccionados</div>
            <div class="gac-numero">{total:,}</div>
            <div class="gac-insignia">
                {porcentaje_total:.1f}% de la base
            </div>
        </div>
        """,
        unsafe_allow_html=True
    )

with tarjeta_2:
    st.markdown(
        f"""
        <div class="gac-tarjeta">
            <div class="gac-titulo">🚗 Con prueba de manejo</div>
            <div class="gac-numero">{porcentaje_pdm:.1f}%</div>
            {comparacion_pdm}
            <div class="gac-detalle">
                {cantidad_pdm:,} de {total:,} registros
            </div>
        </div>
        """,
        unsafe_allow_html=True
    )

with tarjeta_3:
    st.markdown(
        f"""
        <div class="gac-tarjeta">
            <div class="gac-titulo">
                🤝 Con intervención del gerente
            </div>
            <div class="gac-numero">{porcentaje_gerente:.1f}%</div>
            {comparacion_gerente}
            <div class="gac-detalle">
                {cantidad_gerente:,} de {total:,} registros
            </div>
        </div>
        """,
        unsafe_allow_html=True
    )

st.caption(
    "pp = puntos porcentuales. Las flechas comparan "
    "la selección con toda la base."
)

# Colores por estatus
colores_estatus = {
    "Activo": "#0072B2",
    "Cerrado": "#F28E2B",
    "Venta": "#009E73",
    "Finalizado": "#E9B824",
    "No registrado": "#C7C7C7"
}

# Barras superiores
st.subheader("¿En qué estatus están los prospectos?")

tabla_estatus = (
    df_filtrado["Estatus Lead"]
    .value_counts()
    .rename_axis("Estatus")
    .reset_index(name="Frecuencia")
    .sort_values("Frecuencia", ascending=True)
)

tabla_estatus["Porcentaje"] = (
    tabla_estatus["Frecuencia"] / total * 100
)

tabla_estatus["Etiqueta"] = tabla_estatus.apply(
    lambda fila: (
        f'{fila["Frecuencia"]:,} | '
        f'{fila["Porcentaje"]:.1f}%'
    ),
    axis=1
)

fig_estatus = px.bar(
    tabla_estatus,
    x="Frecuencia",
    y="Estatus",
    orientation="h",
    color="Estatus",
    text="Etiqueta",
    color_discrete_map=colores_estatus,
    custom_data=["Porcentaje"]
)

fig_estatus.update_yaxes(
    title=None,
    categoryorder="array",
    categoryarray=tabla_estatus["Estatus"].tolist(),
    automargin=True
)

fig_estatus.update_xaxes(
    type="linear",
    title="Número de registros",
    range=[0, tabla_estatus["Frecuencia"].max() * 1.2],
    showgrid=True
)

fig_estatus.update_traces(
    textposition="outside",
    cliponaxis=False,
    hovertemplate=(
        "Estatus: %{y}<br>"
        "Registros: %{x}<br>"
        "Del total seleccionado: %{customdata[0]:.1f}%"
        "<extra></extra>"
    )
)

fig_estatus.update_layout(
    height=max(230, 30 * len(tabla_estatus) + 80),
    showlegend=False,
    paper_bgcolor="rgba(0,0,0,0)",
    plot_bgcolor="rgba(0,0,0,0)",
    margin=dict(l=10, r=35, t=10, b=35)
)

st.plotly_chart(
    fig_estatus,
    width="stretch",
    key="bitacora_estatus"
)

# Colores de ambas donas
colores_respuesta = {
    "Sí": "#009E73",
    "No": "#D71920",
    "No registrado": "#C7C7C7"
}

# Donas inferiores
col_pdm, col_gerente = st.columns(2)

configuraciones = [
    (
        col_pdm,
        "Prueba de manejo",
        "¿Cuántos prospectos realizaron una prueba de manejo?"
    ),
    (
        col_gerente,
        "Intervención del gerente",
        "¿En cuántas atenciones intervino el gerente?"
    )
]

for columna, variable, titulo in configuraciones:
    tabla = (
        df_filtrado[variable]
        .value_counts()
        .rename_axis("Categoría")
        .reset_index(name="Frecuencia")
    )

    with columna:
        st.subheader(titulo)

        figura = px.pie(
            tabla,
            names="Categoría",
            values="Frecuencia",
            hole=0.65,
            color="Categoría",
            color_discrete_map=colores_respuesta
        )

        figura.update_traces(
            textinfo="label+percent",
            textposition="inside",
            texttemplate="%{label}<br>%{percent:.1%}",
            hovertemplate=(
                "%{label}<br>"
                "Registros: %{value}<br>"
                "Porcentaje: %{percent:.1%}"
                "<extra></extra>"
            )
        )

        figura.update_layout(
            height=290,
            showlegend=True,
            paper_bgcolor="rgba(0,0,0,0)",
            plot_bgcolor="rgba(0,0,0,0)",
            legend=dict(
                title=None,
                orientation="h",
                yanchor="top",
                y=-0.05,
                xanchor="center",
                x=0.5
            ),
            margin=dict(l=20, r=20, t=15, b=50)
        )

        st.plotly_chart(
            figura,
            width="stretch",
            key=f"bitacora_grafica_{variable}"
        )