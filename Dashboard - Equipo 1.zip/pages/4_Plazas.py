import streamlit as st
import pandas as pd
import plotly.express as px
from pathlib import Path
from html import escape

# Configuración
st.set_page_config(
    page_title="GAC | Leads Plazas",
    page_icon="📍",
    layout="wide"
)

CARPETA_BASE = Path(__file__).resolve().parent.parent
CSV = "Plazas_sin_nulos.csv"

PALETA_VINO = [
    "#D71920",
    "#B53B4E",
    "#E89AA4",
    "#7A1F2B",
    "#F2C5CA",
    "#963444",
    "#D46573",
    "#EDB0B7",
    "#A12E40",
    "#DF7F8B"
]

ESCALA_VINO = [
    "#FAF7F7",
    "#F2C5CA",
    "#E89AA4",
    "#D46573",
    "#B53B4E",
    "#7A1F2B",
    "#4A101A"
]


# Limpieza de texto del código original
def arreglar_texto(texto):
    if not isinstance(texto, str):
        return texto

    for codificacion in ("cp1252", "latin-1"):
        try:
            texto = texto.encode(codificacion).decode("utf-8")
            break
        except (UnicodeEncodeError, UnicodeDecodeError):
            continue

    return " ".join(texto.split())


@st.cache_data
def load_data():
    rutas = [
        CARPETA_BASE / CSV,
        CARPETA_BASE / "data" / CSV
    ]

    ruta = next(
        (ruta for ruta in rutas if ruta.exists()),
        None
    )

    if ruta is None:
        raise FileNotFoundError(
            f"No se encontró {CSV} en la carpeta principal ni en data."
        )

    df = pd.read_csv(ruta, encoding="utf-8-sig")

    # Transformaciones del código de tu compañero
    for columna in ["Asesor", "Producto", "Origen", "Estatus"]:
        df[columna] = (
            df[columna]
            .map(arreglar_texto)
            .astype("string")
            .str.strip()
            .fillna("No registrado")
            .replace("", "No registrado")
        )

    df["Producto"] = df["Producto"].str.upper()
    df["Asesor"] = df["Asesor"].str.title()
    df["Origen"] = df["Origen"].str.title()

    df["Estatus"] = df["Estatus"].replace({
        "Contactato": "Contactado",
        "False": "Sin estatus",
        "FALSE": "Sin estatus"
    })

    for columna in ["Seguimiento", "Cita efetiva", "PDM", "SDC"]:
        df[columna] = (
            pd.to_numeric(df[columna], errors="coerce")
            .map({1: "Sí", 0: "No"})
            .fillna("No registrado")
        )

    df["Fecha Origen"] = pd.to_datetime(
        df["Fecha Origen"],
        errors="coerce"
    )

    df["Hora"] = df["Fecha Origen"].dt.hour

    return df


df = load_data()

# Colores estables para cada producto
productos = sorted(df["Producto"].unique().tolist())

MAPA_COLORES = {
    "EMZOOM": "#D71920",
    "EMKOO": "#750015",
    "GS8": "#F59CA5",
    "AION": "#B53B4E",
    "GN8": "#963444",
    "GS4": "#F2C5CA",
    "NO REGISTRADO": "#C7C7C7"
}

# Colores para cualquier producto adicional
for producto in productos:
    MAPA_COLORES.setdefault(producto, "#64748B")

# Barra lateral y filtros
st.sidebar.title("📍 GAC | Leads Plazas")

opciones_origen = sorted(df["Origen"].unique().tolist())

origenes = st.sidebar.multiselect(
    "Plaza de origen",
    options=opciones_origen,
    default=opciones_origen,
    key="plazas_origen"
)

hora_minima, hora_maxima = st.sidebar.slider(
    "Hora de origen del lead",
    min_value=0,
    max_value=23,
    value=(0, 23),
    key="plazas_hora"
)

dff = df[
    df["Origen"].isin(origenes)
    & df["Hora"].between(hora_minima, hora_maxima)
].copy()

sin_fecha = int(df["Fecha Origen"].isna().sum())

if sin_fecha:
    st.sidebar.caption(
        f"{sin_fecha:,} registros sin fecha válida "
        "quedan fuera del análisis por hora."
    )

# Encabezado
col_logo, col_titulo = st.columns([1, 5])

with col_logo:
    st.image(
        str(CARPETA_BASE / "logo_gac.png"),
        width=150
    )

with col_titulo:
    st.title("Leads Plazas")
    st.caption(
        "Interés por producto, plaza de captación "
        "y horario de llegada de los leads"
    )

st.markdown(
    """
    <div style="
        height:4px;
        background:#D71920;
        border-radius:4px;
        margin-bottom:16px;
    "></div>
    """,
    unsafe_allow_html=True
)

# Estilo de las tarjetas
st.markdown(
    """
    <style>
    .gac-tarjeta {
        background: rgba(117, 0, 21, 0.22);
        border: 1px solid rgba(215, 25, 32, 0.25);
        border-radius: 16px;
        padding: 16px 20px;
        margin-bottom: 12px;
        min-height: 140px;
        box-sizing: border-box;
    }

    .gac-titulo {
        color: #F3DDE1;
        font-size: 15px;
        margin-bottom: 8px;
    }

    .gac-numero {
        color: #FFFFFF;
        font-size: 34px;
        font-weight: 700;
        line-height: 1.2;
        overflow-wrap: anywhere;
    }

    .gac-texto {
        font-size: 22px;
    }

    .gac-insignia {
        display: inline-block;
        margin-top: 8px;
        padding: 4px 10px;
        border-radius: 20px;
        background: rgba(255, 255, 255, 0.12);
        color: #FFFFFF;
        font-size: 12px;
    }
    </style>
    """,
    unsafe_allow_html=True
)


def mostrar_tarjeta(titulo, valor, detalle="", texto=False):
    clase = (
        "gac-numero gac-texto"
        if texto else "gac-numero"
    )

    insignia = (
        f'<div class="gac-insignia">{escape(str(detalle))}</div>'
        if detalle else ""
    )

    st.markdown(
        f"""
        <div class="gac-tarjeta">
            <div class="gac-titulo">{escape(str(titulo))}</div>
            <div class="{clase}">{escape(str(valor))}</div>
            {insignia}
        </div>
        """,
        unsafe_allow_html=True
    )


def ajustar_figura(figura, altura=280, leyenda=False):
    figura.update_layout(
        height=altura,
        showlegend=leyenda,
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        margin=dict(l=10, r=20, t=15, b=35),
        font=dict(size=12)
    )

    return figura


if dff.empty:
    st.warning("No hay registros con los filtros seleccionados.")
    st.stop()

# Frecuencias por producto
tabla_frecuencias = (
    dff["Producto"]
    .value_counts()
    .rename_axis("Producto")
    .reset_index(name="Frecuencia")
)

tabla_frecuencias["Porcentaje"] = (
    tabla_frecuencias["Frecuencia"] / len(dff) * 100
)

tabla_frecuencias["Etiqueta"] = tabla_frecuencias.apply(
    lambda fila: (
        f'{fila["Frecuencia"]:,} | '
        f'{fila["Porcentaje"]:.1f}%'
    ),
    axis=1
)

# Producto líder: excluir la etiqueta de dato faltante
productos_registrados = tabla_frecuencias[
    tabla_frecuencias["Producto"] != "NO REGISTRADO"
]

total_productos = len(productos_registrados)

if productos_registrados.empty:
    producto_lider = "Sin dato"
    detalle_lider = "No hay productos registrados"
else:
    top = productos_registrados.iloc[0]
    producto_lider = top["Producto"]
    detalle_lider = (
        f'{top["Porcentaje"]:.1f}% de la selección'
    )

total_seguimiento = int(dff["Seguimiento"].eq("Sí").sum())
porcentaje_seguimiento = total_seguimiento / len(dff) * 100

# Cuatro tarjetas
col_1, col_2, col_3, col_4 = st.columns(4)

with col_1:
    mostrar_tarjeta(
        "Total leads",
        f"{len(dff):,}"
    )

with col_2:
    mostrar_tarjeta(
        "Productos de interés",
        f"{total_productos:,}",
        "Productos distintos registrados"
    )

with col_3:
    mostrar_tarjeta(
        "Producto más solicitado",
        producto_lider,
        detalle_lider,
        texto=True
    )

with col_4:
    mostrar_tarjeta(
        "Leads con seguimiento",
        f"{porcentaje_seguimiento:.1f}%",
        f"{total_seguimiento:,} de {len(dff):,} leads"
    )

# Fila 1
col_barras, col_proporcion = st.columns(2)

with col_barras:
    st.subheader("¿Qué productos generan más interés?")

    tabla_barras = tabla_frecuencias.sort_values(
        "Frecuencia",
        ascending=True
    )

    fig_barras = px.bar(
        tabla_barras,
        x="Frecuencia",
        y="Producto",
        orientation="h",
        color="Producto",
        text="Etiqueta",
        color_discrete_map=MAPA_COLORES,
        custom_data=["Porcentaje"]
    )

    fig_barras.update_traces(
        textposition="outside",
        cliponaxis=False,
        hovertemplate=(
            "Producto: %{y}<br>"
            "Leads: %{x}<br>"
            "Del total seleccionado: %{customdata[0]:.1f}%"
            "<extra></extra>"
        )
    )

    fig_barras.update_xaxes(
        title="Número de leads",
        range=[
            0,
            tabla_barras["Frecuencia"].max() * 1.4
        ]
    )

    fig_barras.update_yaxes(
        title=None,
        categoryorder="array",
        categoryarray=tabla_barras["Producto"].tolist(),
        automargin=True
    )

    st.plotly_chart(
        ajustar_figura(fig_barras),
        width="stretch",
        key="plazas_barras"
    )

with col_proporcion:
    st.subheader("¿Qué plazas captan más leads?")

    tabla_plazas = (
        dff["Origen"]
        .value_counts()
        .rename_axis("Plaza")
        .reset_index(name="Leads")
        .sort_values("Leads", ascending=True)
    )

    tabla_plazas["Porcentaje"] = (
        tabla_plazas["Leads"] / len(dff) * 100
    )

    tabla_plazas["Etiqueta"] = tabla_plazas.apply(
        lambda fila: (
            f'{fila["Leads"]:,} | '
            f'{fila["Porcentaje"]:.1f}%'
        ),
        axis=1
    )

    fig_plazas = px.bar(
        tabla_plazas,
        x="Leads",
        y="Plaza",
        orientation="h",
        color="Plaza",
        color_discrete_map={
            "Galerias Tlaxcala": "#F59CA5",
            "Gran Patio Tlaxcala": "#B53B4E",
            "Plaza Angelopolis": "#D71920"
        },
        text="Etiqueta",
        custom_data=["Porcentaje"]
    )

    fig_plazas.update_traces(
        textposition="outside",
        cliponaxis=False,
        hovertemplate=(
            "Plaza: %{y}<br>"
            "Leads: %{x}<br>"
            "Del total seleccionado: %{customdata[0]:.1f}%"
            "<extra></extra>"
        )
    )

    fig_plazas.update_xaxes(
        title="Número de leads",
        range=[0, tabla_plazas["Leads"].max() * 1.4]
    )

    fig_plazas.update_yaxes(
        title=None,
        categoryorder="array",
        categoryarray=tabla_plazas["Plaza"].tolist(),
        automargin=True
    )

    st.plotly_chart(
        ajustar_figura(fig_plazas),
        width="stretch",
        key="plazas_captacion"
    )

# Fila 2
col_heatmap, col_boxplot = st.columns(2)

with col_heatmap:
    st.subheader("¿Qué productos destacan en cada plaza?")
    st.caption("Cantidad de leads por producto y plaza.")

    tabla_cruce = pd.crosstab(
        dff["Producto"],
        dff["Origen"]
    )

    tabla_cruce = tabla_cruce.reindex(
        index=tabla_frecuencias["Producto"].tolist()
    )

    fig_heatmap = px.imshow(
        tabla_cruce,
        text_auto=True,
        aspect="auto",
        color_continuous_scale=ESCALA_VINO,
        labels={
            "x": "Plaza",
            "y": "Producto",
            "color": "Leads"
        }
    )

    fig_heatmap.update_traces(
        hovertemplate=(
            "Plaza: %{x}<br>"
            "Producto: %{y}<br>"
            "Leads: %{z}"
            "<extra></extra>"
        )
    )

    fig_heatmap.update_xaxes(
        title=None,
        automargin=True,
        tickangle=-25
    )

    fig_heatmap.update_yaxes(
        title=None,
        automargin=True
    )

    st.plotly_chart(
        ajustar_figura(fig_heatmap),
        width="stretch",
        key="plazas_heatmap"
    )

with col_boxplot:
    st.subheader("¿A qué hora llegan los leads de cada producto?")
    st.caption("Distribución de la hora registrada de origen.")

    fig_boxplot = px.box(
        dff,
        x="Producto",
        y="Hora",
        color="Producto",
        points="outliers",
        color_discrete_map=MAPA_COLORES,
        category_orders={
            "Producto": tabla_frecuencias["Producto"].tolist()
        }
    )

    fig_boxplot.update_xaxes(
        title=None,
        automargin=True,
        tickangle=-25
    )

    fig_boxplot.update_yaxes(
        title="Hora del día",
        range=[-0.5, 23.5],
        tickvals=[0, 4, 8, 12, 16, 20, 23],
        ticktext=[
            "00:00", "04:00", "08:00", "12:00",
            "16:00", "20:00", "23:00"
        ]
    )

    st.plotly_chart(
        ajustar_figura(fig_boxplot),
        width="stretch",
        key="plazas_boxplot"
    )