import streamlit as st
import plotly.express as px
import pandas as pd
from pathlib import Path
from html import escape

# Configuración
st.set_page_config(
    page_title="GAC | Tlaxcala",
    page_icon="🚗",
    layout="wide"
)

CARPETA_BASE = Path(__file__).resolve().parent.parent


# Cargar datos
@st.cache_data
def load_data():
    df = pd.read_csv(
        CARPETA_BASE / "Base_de_Tlaxcala.csv"
    )

    df.columns = df.columns.str.strip()

    for columna in ["Producto", "Temperatura", "Estatus"]:
        df[columna] = (
            df[columna]
            .astype("string")
            .str.strip()
            .replace("", pd.NA)
            .fillna("No registrado")
        )

    return df


df = load_data()

# Barra lateral
st.sidebar.title("🚗 GAC | Tlaxcala")

productos = sorted(df["Producto"].unique().tolist())

productos_seleccionados = st.sidebar.multiselect(
    "Filtrar por producto",
    options=productos,
    default=productos,
    key="tlaxcala_productos"
)

df_filtrado = df[
    df["Producto"].isin(productos_seleccionados)
].copy()

# Encabezado
col_logo, col_titulo = st.columns([1, 5])

with col_logo:
    st.image(
        str(CARPETA_BASE / "logo_gac.png"),
        width=150
    )

with col_titulo:
    st.title("Leads | GAC Tlaxcala")
    st.caption(
        "Producto, nivel de interés y estatus de los leads"
    )

st.markdown(
    """
    <div style="
        height:4px;
        background:#D71920;
        border-radius:4px;
        margin-bottom:20px;
    "></div>
    """,
    unsafe_allow_html=True
)

# Diseño de las tarjetas
st.markdown(
    """
    <style>
    .gac-tarjeta {
        background: rgba(117, 0, 21, 0.22);
        border: 1px solid rgba(215, 25, 32, 0.25);
        border-radius: 16px;
        padding: 20px 24px;
        margin-bottom: 20px;
        min-height: 165px;
        box-sizing: border-box;
    }

    .gac-titulo {
        color: #F3DDE1;
        font-size: 15px;
        margin-bottom: 10px;
    }

    .gac-valor {
        color: #FFFFFF;
        font-size: 32px;
        font-weight: 700;
        line-height: 1.2;
        overflow-wrap: anywhere;
    }

    .gac-insignia {
        display: inline-block;
        margin-top: 10px;
        padding: 4px 10px;
        border-radius: 20px;
        background: rgba(255, 255, 255, 0.12);
        color: #FFFFFF;
        font-size: 12px;
    }
    </style>
    """,
    unsafe_allow_html=True
)

if df_filtrado.empty:
    st.warning("Selecciona al menos un producto con registros.")
    st.stop()

# Indicadores
total_seleccionado = len(df_filtrado)

porcentaje_total = (
    total_seleccionado / len(df) * 100
    if len(df) > 0 else 0
)

temperatura_normalizada = (
    df_filtrado["Temperatura"]
    .str.strip()
    .str.casefold()
)

estatus_normalizado = (
    df_filtrado["Estatus"]
    .str.strip()
    .str.casefold()
)

muy_interesados = int(
    temperatura_normalizada.eq("lead muy interesado").sum()
)

contactados = int(
    estatus_normalizado.eq("contactado").sum()
)

finalizados = int(
    estatus_normalizado.eq("finalizado").sum()
)


def mostrar_tarjeta(titulo, cantidad, detalle):
    st.markdown(
        f"""
        <div class="gac-tarjeta">
            <div class="gac-titulo">{escape(titulo)}</div>
            <div class="gac-valor">{cantidad:,}</div>
            <div class="gac-insignia">{escape(detalle)}</div>
        </div>
        """,
        unsafe_allow_html=True
    )


def porcentaje_seleccion(cantidad):
    porcentaje = cantidad / total_seleccionado * 100
    return f"{porcentaje:.1f}% de la selección"


# Cuatro tarjetas
col_total, col_interesados, col_contactados, col_finalizados = (
    st.columns(4)
)

with col_total:
    mostrar_tarjeta(
        "📋 Total leads",
        total_seleccionado,
        f"{porcentaje_total:.1f}% de la base"
    )

with col_interesados:
    mostrar_tarjeta(
        "🔥 Leads muy interesados",
        muy_interesados,
        porcentaje_seleccion(muy_interesados)
    )

with col_contactados:
    mostrar_tarjeta(
        "📞 Leads contactados",
        contactados,
        porcentaje_seleccion(contactados)
    )

with col_finalizados:
    mostrar_tarjeta(
        "📌 Leads finalizados",
        finalizados,
        porcentaje_seleccion(finalizados)
    )

# Colores por producto
colores_productos = {
    "EMKOO": "#750015",
    "EMZOOM": "#D71920",
    "GS8": "#F59CA5"
}

# Gráfica superior
tabla_producto = (
    df_filtrado["Producto"]
    .value_counts()
    .rename_axis("Producto")
    .reset_index(name="Frecuencia")
)

figura_producto = px.bar(
    tabla_producto,
    x="Frecuencia",
    y="Producto",
    orientation="h",
    color="Producto",
    text="Frecuencia",
    title="¿Qué productos generan más interés?",
    color_discrete_map=colores_productos
)

figura_producto.update_yaxes(
    categoryorder="total ascending",
    title=None
)

figura_producto.update_xaxes(
    title="Número de leads",
    range=[
        0,
        tabla_producto["Frecuencia"].max() * 1.12
    ],
    dtick=1 if tabla_producto["Frecuencia"].max() < 10 else None
)

figura_producto.update_traces(
    textposition="outside",
    cliponaxis=False,
    hovertemplate=(
        "Producto: %{y}<br>"
        "Leads: %{x}"
        "<extra></extra>"
    )
)

figura_producto.update_layout(
    height=max(250, 35 * len(tabla_producto) + 80),
    showlegend=False,
    paper_bgcolor="rgba(0,0,0,0)",
    plot_bgcolor="rgba(0,0,0,0)",
    margin=dict(l=10, r=35, t=50, b=30)
)

st.plotly_chart(
    figura_producto,
    width="stretch",
    key="tlaxcala_productos_grafica"
)

# Colores por nivel de interés y estatus
colores_categorias = {
    "lead interes bajo": "#D71920",
    "lead interes medio": "#E9B824",
    "lead muy interesado": "#009E73",
    "finalizado": "#B53B4E",
    "contactado": "#E9B824",
    "no registrado": "#C7C7C7"
}

titulos_graficas = {
    "Temperatura": "¿Qué nivel de interés tienen los leads?",
    "Estatus": "¿En qué estatus están los leads?"
}

# Gráficas inferiores
col_temperatura, col_estatus = st.columns(2)

for columna, variable in zip(
    [col_temperatura, col_estatus],
    ["Temperatura", "Estatus"]
):
    datos_grafica = df_filtrado.copy()
    excluidos = 0

    # Excluir esta etiqueta únicamente de la dona de estatus
    if variable == "Estatus":
        excluir = (
            datos_grafica["Estatus"]
            .str.strip()
            .str.casefold()
            .eq("1 ventas")
        )

        excluidos = int(excluir.sum())
        datos_grafica = datos_grafica.loc[~excluir].copy()

    tabla = (
        datos_grafica[variable]
        .value_counts()
        .rename_axis("Categoría")
        .reset_index(name="Frecuencia")
    )

    with columna:
        if tabla.empty:
            st.info(
                f"No hay datos disponibles para "
                f"{variable.lower()} en esta selección."
            )
            continue

        mapa_colores = {
            categoria: colores_categorias.get(
                categoria.strip().casefold(),
                "#64748B"
            )
            for categoria in tabla["Categoría"]
        }

        figura = px.pie(
            tabla,
            names="Categoría",
            values="Frecuencia",
            hole=0.6,
            color="Categoría",
            title=titulos_graficas[variable],
            color_discrete_map=mapa_colores
        )

        figura.update_traces(
            textinfo="percent",
            textposition="inside",
            texttemplate="%{percent:.1%}",
            hovertemplate=(
                "%{label}<br>"
                "Leads: %{value}<br>"
                "Porcentaje: %{percent:.1%}"
                "<extra></extra>"
            )
        )

        figura.update_layout(
            height=320,
            paper_bgcolor="rgba(0,0,0,0)",
            plot_bgcolor="rgba(0,0,0,0)",
            legend=dict(
                title=None,
                orientation="h",
                yanchor="top",
                y=-0.1,
                xanchor="center",
                x=0.5
            ),
            margin=dict(l=10, r=10, t=60, b=65)
        )

        st.plotly_chart(
            figura,
            width="stretch",
            key=f"tlaxcala_{variable}"
        )

        if variable == "Estatus" and excluidos > 0:
            st.caption(
                f"Esta gráfica usa {len(datos_grafica):,} leads; "
                f"excluye {excluidos:,} con la etiqueta «1 Ventas». "
                "Las tarjetas usan todos los leads seleccionados."
            )