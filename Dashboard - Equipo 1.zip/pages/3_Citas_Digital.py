import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from pathlib import Path

# Configurar la página
st.set_page_config(
    page_title="GAC | Citas Digital",
    page_icon="📅",
    layout="wide"
)

# Carpeta principal del dashboard
CARPETA_BASE = Path(__file__).resolve().parent.parent


# Cargar y limpiar los datos
@st.cache_data
def load_data():
    df = pd.read_csv(
        CARPETA_BASE / "GAC_CitasDigital_Looker_FINAL.csv"
    )

    for variable in ["estatus_lead", "bdc", "asesor"]:
        df[variable] = (
            df[variable]
            .astype("string")
            .str.strip()
            .replace("", pd.NA)
            .fillna("No registrado")
        )

    df["bdc"] = df["bdc"].replace({
        "Igancio": "Ignacio"
    })

    # El CSV usa mes/día/año
    df["fecha"] = pd.to_datetime(
        df["fecha"],
        format="%m/%d/%Y",
        errors="coerce"
    )

    # Conservar el dato original para revisar las correcciones
    df["asesor_original"] = df["asesor"]

    # Unificar etiquetas que no identifican a un asesor
    etiquetas_sin_asesor = [
        "Sin asignar",
        "Casa",
        "Gerencia",
        "Nos Vista Lunes 7",
        "Nos Visita El Sabado 5",
        "Ya Visito La Agencia",
        "Llamada"
    ]

    df["asesor"] = df["asesor"].replace({
        etiqueta: "No registrado"
        for etiqueta in etiquetas_sin_asesor
    })

    return df


df = load_data()

# Barra lateral y filtros
st.sidebar.title("📅 GAC | Citas Digital")

# Filtro de fecha
fechas_validas = df["fecha"].dropna()

incluir_sin_fecha = st.sidebar.checkbox(
    "Incluir registros sin fecha válida",
    value=False,
    key="citas_incluir_sin_fecha"
)

if not fechas_validas.empty:
    fecha_minima = fechas_validas.min().date()
    fecha_maxima = fechas_validas.max().date()

    rango_fechas = st.sidebar.date_input(
        "Periodo de análisis",
        value=(fecha_minima, fecha_maxima),
        min_value=fecha_minima,
        max_value=fecha_maxima,
        key="citas_rango_fechas"
    )

    if len(rango_fechas) != 2:
        st.info("Selecciona la fecha inicial y la final.")
        st.stop()

    fecha_inicio, fecha_fin = rango_fechas

    filtro_fecha = df["fecha"].dt.date.between(
        fecha_inicio, fecha_fin
    )
else:
    st.sidebar.warning("La base no tiene fechas válidas.")
    filtro_fecha = pd.Series(False, index=df.index)

if incluir_sin_fecha:
    filtro_fecha = filtro_fecha | df["fecha"].isna()

# Filtro por responsable BDC
opciones_bdc = sorted(df["bdc"].unique().tolist())

bdc_seleccionados = st.sidebar.multiselect(
    "Responsable BDC",
    options=opciones_bdc,
    default=opciones_bdc,
    key="citas_digital_bdc"
)

# Filtro por asesor
opciones_asesor = sorted(df["asesor"].unique().tolist())

asesores_seleccionados = st.sidebar.multiselect(
    "Asesor",
    options=opciones_asesor,
    default=opciones_asesor,
    key="citas_digital_asesor"
)

# Filtro por estatus
opciones_estatus = sorted(df["estatus_lead"].unique().tolist())

estatus_seleccionados = st.sidebar.multiselect(
    "Estatus del lead",
    options=opciones_estatus,
    default=opciones_estatus,
    key="citas_digital_estatus"
)

# Aplicar todos los filtros
df_filtrado = df[
    filtro_fecha
    & df["bdc"].isin(bdc_seleccionados)
    & df["asesor"].isin(asesores_seleccionados)
    & df["estatus_lead"].isin(estatus_seleccionados)
].copy()

# Encabezado
col_logo, col_titulo = st.columns([1, 5])

with col_logo:
    st.image(
        str(CARPETA_BASE / "logo_gac.png"),
        width=150
    )

with col_titulo:
    st.title("Citas Digital")
    st.caption(
        "Estatus de los leads y distribución por BDC y asesor"
    )

st.markdown(
    """
    <div style="
        height:4px;
        background:#D71920;
        border-radius:4px;
        margin-bottom:20px;
    "></div>
    """,
    unsafe_allow_html=True
)

# Diseño de las tarjetas
st.markdown(
    """
    <style>
    .gac-tarjeta {
        background: rgba(117, 0, 21, 0.22);
        border: 1px solid rgba(215, 25, 32, 0.25);
        border-radius: 16px;
        padding: 20px 24px;
        margin-bottom: 20px;
        height: 165px;
        box-sizing: border-box;
    }

    .gac-titulo {
        color: #F3DDE1;
        font-size: 15px;
        margin-bottom: 10px;
    }

    .gac-numero {
        color: #FFFFFF;
        font-size: 38px;
        font-weight: 700;
        line-height: 1.2;
    }

    .gac-insignia {
        display: inline-block;
        margin-top: 10px;
        padding: 4px 10px;
        border-radius: 20px;
        background: rgba(255, 255, 255, 0.12);
        color: #FFFFFF;
        font-size: 12px;
    }
    </style>
    """,
    unsafe_allow_html=True
)

# Indicadores calculados con los filtros
total_seleccionado = len(df_filtrado)

estatus_normalizado = (
    df_filtrado["estatus_lead"]
    .astype("string")
    .str.strip()
    .str.casefold()
)

activos = int(estatus_normalizado.eq("activo").sum())
ventas = int(estatus_normalizado.isin(["venta", "ventas"]).sum())
finalizados = int(estatus_normalizado.eq("finalizado").sum())


# Crear una tarjeta
def mostrar_tarjeta(titulo, cantidad, mostrar_porcentaje=False):
    insignia = ""

    if mostrar_porcentaje and total_seleccionado > 0:
        porcentaje = cantidad / total_seleccionado * 100

        insignia = (
            '<div class="gac-insignia">'
            f'{porcentaje:.1f}% de la selección'
            '</div>'
        )

    st.markdown(
        f"""
        <div class="gac-tarjeta">
            <div class="gac-titulo">{titulo}</div>
            <div class="gac-numero">{cantidad:,}</div>
            {insignia}
        </div>
        """,
        unsafe_allow_html=True
    )

# Referencia: mismo periodo y BDC, todos los asesores
base_referencia = df[
    filtro_fecha
    & df["bdc"].isin(bdc_seleccionados)
].copy()

# Selección de asesores, antes del filtro de estatus
base_asesores = base_referencia[
    base_referencia["asesor"].isin(asesores_seleccionados)
].copy()


def tasa_ventas(datos):
    estatus = (
        datos["estatus_lead"]
        .astype("string")
        .str.strip()
        .str.casefold()
    )

    return estatus.isin(["venta", "ventas"]).mean() * 100


# Insignia del semáforo
if base_referencia.empty or base_asesores.empty:
    insignia_ventas = (
        '<div class="gac-insignia">'
        'Sin datos para comparar'
        '</div>'
    )
else:
    tasa_referencia = tasa_ventas(base_referencia)
    tasa_seleccion = tasa_ventas(base_asesores)

    diferencia = tasa_seleccion - tasa_referencia

    if diferencia > 1:
        color = "#6EE7B7"
        fondo = "rgba(0, 158, 115, 0.18)"
        texto = f"↑ {diferencia:.1f} pp sobre referencia"

    elif diferencia < -1:
        color = "#FCA5A5"
        fondo = "rgba(215, 25, 32, 0.18)"
        texto = f"↓ {abs(diferencia):.1f} pp bajo referencia"

    else:
        color = "#FDE68A"
        fondo = "rgba(233, 184, 36, 0.18)"
        texto = "≈ Cerca de la referencia"

    insignia_ventas = (
        '<div class="gac-insignia" '
        f'style="color:{color}; background:{fondo};">'
        f'{texto}</div>'
    )

# Cuatro tarjetas de resumen
col_total, col_activos, col_ventas, col_finalizados = st.columns(4)

with col_total:
    mostrar_tarjeta("Total leads", total_seleccionado)

with col_activos:
    mostrar_tarjeta("Activos", activos, True)

with col_ventas:
    st.markdown(
        f"""
        <div class="gac-tarjeta">
            <div class="gac-titulo">Ventas</div>
            <div class="gac-numero">{ventas:,}</div>
            {insignia_ventas}
        </div>
        """,
        unsafe_allow_html=True
    )

with col_finalizados:
    mostrar_tarjeta("Finalizados", finalizados, True)

st.caption(
    "Semáforo: proporción de ventas de los asesores seleccionados "
    "frente a todos los asesores del mismo periodo y BDC. "
    "Margen provisional: ±1 punto porcentual (pp). "
    "La comparación no aplica el filtro de estatus."
)
# Evitar gráficas vacías
if df_filtrado.empty:
    st.warning(
        "No hay registros para esta combinación de filtros."
    )
    st.stop()

# Dos gráficas lado a lado
col_asesor, col_heatmap = st.columns(2)

tabla_asesores = (
    df_filtrado.loc[
        ~df_filtrado["asesor"]
        .str.strip()
        .str.casefold()
        .isin(["no registrado", "sin asignar", "sin información"]),
        "asesor"
    ]
    .value_counts()
    .head(10)
    .sort_values()
    .rename_axis("Asesor")
    .reset_index(name="Frecuencia")
)

# Porcentaje sobre todos los registros seleccionados
tabla_asesores["Porcentaje"] = (
    tabla_asesores["Frecuencia"]
    / total_seleccionado
    * 100
)

tabla_asesores["Etiqueta"] = tabla_asesores.apply(
    lambda fila: (
        f'{fila["Frecuencia"]:,} | '
        f'{fila["Porcentaje"]:.1f}%'
    ),
    axis=1
)

paleta_vino = [
    "#F2C5CA",
    "#EDB0B7",
    "#E89AA4",
    "#DF7F8B",
    "#D46573",
    "#C64E60",
    "#B53B4E",
    "#A12E40",
    "#8D2434",
    "#7A1F2B"
]

fig_asesor = px.bar(
    tabla_asesores,
    x="Frecuencia",
    y="Asesor",
    orientation="h",
    color="Asesor",
    text="Etiqueta",
    color_discrete_sequence=paleta_vino,
    custom_data=["Porcentaje"]
)

fig_asesor.update_traces(
    textposition="outside",
    cliponaxis=False,
    hovertemplate=(
        "%{y}<br>"
        "Leads: %{x}<br>"
        "Porcentaje: %{customdata[0]:.1f}%"
        "<extra></extra>"
    )
)

fig_asesor.update_yaxes(
    title=None,
    categoryorder="array",
    categoryarray=tabla_asesores["Asesor"].tolist(),
    automargin=True
)

fig_asesor.update_xaxes(
    title="Número de leads",
    range=[
        0,
        tabla_asesores["Frecuencia"].max() * 1.4
    ]
)

fig_asesor.update_layout(
    height=380,
    showlegend=False,
    paper_bgcolor="rgba(0,0,0,0)",
    plot_bgcolor="rgba(0,0,0,0)",
    margin=dict(l=10, r=70, t=10, b=35)
)

with col_asesor:
    st.subheader("Asesores con más leads asignados")
    st.caption(
        "Leads asignados y porcentaje del total seleccionado"
    )
    st.plotly_chart(
        fig_asesor,
        width="stretch",
        key="citas_grafica_asesores"
    )

# Heatmap de estatus por responsable BDC
tabla_heatmap = pd.crosstab(
    df_filtrado["bdc"],
    df_filtrado["estatus_lead"]
)

# Ordenar responsables por cantidad de leads
tabla_heatmap = tabla_heatmap.loc[
    tabla_heatmap.sum(axis=1)
    .sort_values(ascending=False)
    .index
]

# Porcentajes dentro de cada responsable BDC
tabla_porcentajes = (
    tabla_heatmap.div(
        tabla_heatmap.sum(axis=1),
        axis=0
    ) * 100
)

# Etiquetas con cantidad y porcentaje
etiquetas = [
    [
        (
            f"{tabla_heatmap.loc[bdc, estatus]}"
            f"<br>{tabla_porcentajes.loc[bdc, estatus]:.1f}%"
        )
        for estatus in tabla_heatmap.columns
    ]
    for bdc in tabla_heatmap.index
]

escala_vino = [
    "#FAF7F7",
    "#F2C5CA",
    "#E89AA4",
    "#D46573",
    "#B53B4E",
    "#963444",
    "#7A1F2B",
    "#4A101A"
]

fig_heatmap = go.Figure(
    go.Heatmap(
        z=tabla_heatmap.to_numpy(),
        x=tabla_heatmap.columns.tolist(),
        y=tabla_heatmap.index.tolist(),
        text=etiquetas,
        texttemplate="%{text}",
        customdata=tabla_porcentajes.to_numpy(),
        colorscale=escala_vino,
        zmin=0,
        xgap=2,
        ygap=2,
        colorbar=dict(
            title="Leads",
            thickness=12,
            len=0.8
        ),
        hovertemplate=(
            "BDC: %{y}<br>"
            "Estatus: %{x}<br>"
            "Leads: %{z}<br>"
            "Dentro del BDC: %{customdata:.1f}%"
            "<extra></extra>"
        )
    )
)

fig_heatmap.update_xaxes(
    title=None,
    tickangle=0,
    side="bottom"
)

fig_heatmap.update_yaxes(
    title=None,
    autorange="reversed",
    automargin=True
)

fig_heatmap.update_layout(
    height=380,
    paper_bgcolor="rgba(0,0,0,0)",
    plot_bgcolor="rgba(0,0,0,0)",
    margin=dict(l=10, r=10, t=10, b=35)
)

with col_heatmap:
    st.subheader("¿En qué estatus están los leads de cada BDC?")
    st.caption(
        "Cantidad de leads y porcentaje dentro de cada responsable"
    )
    st.plotly_chart(
        fig_heatmap,
        width="stretch",
        key="citas_grafica_heatmap"
    )