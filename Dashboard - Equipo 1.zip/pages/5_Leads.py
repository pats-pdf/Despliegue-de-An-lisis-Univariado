import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
from pathlib import Path
from html import escape

# Configuración
st.set_page_config(
    page_title="GAC | Ventas y conversión",
    page_icon="📊",
    layout="wide"
)

CARPETA_BASE = Path(__file__).resolve().parent.parent

MESES = {
    1: "Ene", 2: "Feb", 3: "Mar", 4: "Abr",
    5: "May", 6: "Jun", 7: "Jul", 8: "Ago",
    9: "Sep", 10: "Oct", 11: "Nov", 12: "Dic"
}

CATEGORIAS = [
    "Efectivos",
    "Ilocalizable",
    "No Contesta",
    "D. Incorrectos",
    "Duplicados"
]

ETIQUETAS = {
    "Efectivos": "Efectivos",
    "Ilocalizable": "Ilocalizables",
    "No Contesta": "No contestan",
    "D. Incorrectos": "Datos incorrectos",
    "Duplicados": "Duplicados"
}

COLORES_CALIDAD = {
    "Efectivos": "#750015",
    "Ilocalizables": "#B53B4E",
    "No contestan": "#D46573",
    "Datos incorrectos": "#E89AA4",
    "Duplicados": "#F2C5CA"
}

ESCALA_VINO = [
    "#FAF7F7",
    "#F2C5CA",
    "#E89AA4",
    "#D46573",
    "#B53B4E",
    "#7A1F2B",
    "#4A101A"
]


# Cargar y preparar datos
@st.cache_data
def load_data():
    rutas = [
        CARPETA_BASE / "base leads.csv",
        CARPETA_BASE / "data" / "base leads.csv"
    ]

    ruta = next(
        (ruta for ruta in rutas if ruta.exists()),
        None
    )

    if ruta is None:
        raise FileNotFoundError(
            "No se encontró base leads.csv en la carpeta principal "
            "ni en data."
        )

    data = pd.read_csv(ruta)
    data.columns = data.columns.str.strip()

    columnas_numericas = [
        "Año", "Mes", "Total", "Ventas"
    ] + CATEGORIAS

    for columna in columnas_numericas:
        data[columna] = pd.to_numeric(
            data[columna],
            errors="coerce"
        )

    data["Fecha"] = pd.to_datetime(
        {
            "year": data["Año"],
            "month": data["Mes"],
            "day": 1
        },
        errors="coerce"
    )

    # Mismo criterio del notebook: meses con leads
    data = data[
        data["Fecha"].notna()
        & data["Total"].gt(0)
    ].copy()

    data["Año"] = data["Año"].astype(int)
    data["Mes"] = data["Mes"].astype(int)

    # Consolidar por año y mes
    data = (
        data.groupby(
            ["Año", "Mes", "Fecha"],
            as_index=False
        )[["Total", "Ventas"] + CATEGORIAS]
        .sum(min_count=1)
        .sort_values("Fecha")
        .reset_index(drop=True)
    )

    # Conversión sobre leads efectivos
    data["Conv_Efectivos"] = (
        data["Ventas"].div(
            data["Efectivos"].where(data["Efectivos"].gt(0))
        ) * 100
    )

    # Conversión sobre todos los leads
    data["Conv_Total"] = (
        data["Ventas"].div(data["Total"]) * 100
    )

    # Denominador utilizado en la gráfica de calidad
    data["Suma_Cat"] = data[CATEGORIAS].sum(
        axis=1,
        min_count=len(CATEGORIAS)
    )

    data["Periodo"] = (
        data["Mes"].map(MESES)
        + " "
        + data["Año"].astype(str)
    )

    return data


data = load_data()

# Barra lateral
st.sidebar.title("📊 GAC | Ventas y conversión")

anios = sorted(data["Año"].unique().tolist())

anios_seleccionados = st.sidebar.multiselect(
    "Año",
    options=anios,
    default=anios,
    key="leads_anios"
)

meses_disponibles = sorted(
    data.loc[
        data["Año"].isin(anios_seleccionados),
        "Mes"
    ].unique().tolist()
)

meses_seleccionados = st.sidebar.multiselect(
    "Mes",
    options=meses_disponibles,
    default=meses_disponibles,
    format_func=lambda mes: MESES[mes],
    key="leads_meses"
)

data_f = data[
    data["Año"].isin(anios_seleccionados)
    & data["Mes"].isin(meses_seleccionados)
].copy()

# Encabezado
col_logo, col_titulo = st.columns([1, 5])

with col_logo:
    st.image(
        str(CARPETA_BASE / "logo_gac.png"),
        width=150
    )

with col_titulo:
    st.title("Leads | Ventas y conversión")
    st.caption(
        "Resultados comerciales y calidad de los leads "
        "en los meses seleccionados"
    )

st.markdown(
    """
    <div style="
        height:4px;
        background:#D71920;
        border-radius:4px;
        margin-bottom:16px;
    "></div>
    """,
    unsafe_allow_html=True
)

# Diseño de tarjetas
st.markdown(
    """
    <style>
    .gac-tarjeta {
        background: rgba(117, 0, 21, 0.22);
        border: 1px solid rgba(215, 25, 32, 0.25);
        border-radius: 16px;
        padding: 16px 20px;
        margin-bottom: 12px;
        min-height: 140px;
        box-sizing: border-box;
    }

    .gac-titulo {
        color: #F3DDE1;
        font-size: 15px;
        margin-bottom: 8px;
    }

    .gac-valor {
        color: #FFFFFF;
        font-size: 34px;
        font-weight: 700;
        line-height: 1.2;
    }

    .gac-insignia {
        display: inline-block;
        margin-top: 8px;
        padding: 4px 10px;
        border-radius: 20px;
        background: rgba(255,255,255,0.12);
        color: #FFFFFF;
        font-size: 12px;
    }
    </style>
    """,
    unsafe_allow_html=True
)


def mostrar_tarjeta(titulo, valor, detalle):
    st.markdown(
        f"""
        <div class="gac-tarjeta">
            <div class="gac-titulo">{escape(titulo)}</div>
            <div class="gac-valor">{escape(str(valor))}</div>
            <div class="gac-insignia">{escape(detalle)}</div>
        </div>
        """,
        unsafe_allow_html=True
    )


def ajustar_figura(figura, altura=285, leyenda=False):
    figura.update_layout(
        height=altura,
        showlegend=leyenda,
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        margin=dict(l=10, r=15, t=15, b=35),
        font=dict(size=12)
    )

    return figura


if data_f.empty:
    st.warning("No hay datos para los años y meses seleccionados.")
    st.stop()

# Indicadores calculados sobre los totales seleccionados
total_leads = data_f["Total"].sum()
total_efectivos = data_f["Efectivos"].sum()
total_ventas = data_f["Ventas"].sum()

porcentaje_efectivos = total_efectivos / total_leads * 100
conversion_total = total_ventas / total_leads * 100

conversion_efectivos = (
    total_ventas / total_efectivos * 100
    if total_efectivos > 0 else None
)

col_1, col_2, col_3, col_4 = st.columns(4)

with col_1:
    mostrar_tarjeta(
        "📋 Total leads",
        f"{total_leads:,.0f}",
        f"{len(data_f):,} meses con registros"
    )

with col_2:
    mostrar_tarjeta(
        "👥 Leads efectivos",
        f"{total_efectivos:,.0f}",
        f"{porcentaje_efectivos:.1f}% del total de leads"
    )

with col_3:
    mostrar_tarjeta(
        "🚗 Ventas",
        f"{total_ventas:,.0f}",
        f"{conversion_total:.1f}% del total de leads"
    )

with col_4:
    mostrar_tarjeta(
        "🎯 Conversión de efectivos",
        (
            f"{conversion_efectivos:.1f}%"
            if conversion_efectivos is not None
            else "Sin datos"
        ),
        "Ventas / leads efectivos"
    )

# Fila 1: evolución y embudo
col_evolucion, col_embudo = st.columns(2)

with col_evolucion:
    st.subheader("¿Cómo evolucionan las ventas y la conversión?")

    fig_evolucion = make_subplots(
        specs=[[{"secondary_y": True}]]
    )

    fig_evolucion.add_trace(
        go.Bar(
            x=data_f["Fecha"],
            y=data_f["Ventas"],
            name="Ventas",
            marker_color="#D71920",
            hovertemplate=(
                "%{x|%m/%Y}<br>"
                "Ventas: %{y:,.0f}"
                "<extra></extra>"
            )
        ),
        secondary_y=False
    )

    fig_evolucion.add_trace(
        go.Scatter(
            x=data_f["Fecha"],
            y=data_f["Conv_Efectivos"],
            name="Conversión de efectivos",
            mode="lines+markers",
            line=dict(color="#F2C5CA", width=2),
            connectgaps=False,
            hovertemplate=(
                "%{x|%m/%Y}<br>"
                "Conversión: %{y:.1f}%"
                "<extra></extra>"
            )
        ),
        secondary_y=True
    )

    fig_evolucion.update_yaxes(
        title_text="Ventas",
        rangemode="tozero",
        secondary_y=False
    )

    fig_evolucion.update_yaxes(
        title_text="Conversión de efectivos",
        ticksuffix="%",
        tickformat=".1f",
        rangemode="tozero",
        secondary_y=True
    )

    fig_evolucion.update_xaxes(
        title=None,
        tickformat="%m/%Y"
    )

    ajustar_figura(fig_evolucion, leyenda=True)

    fig_evolucion.update_layout(
        legend=dict(
            orientation="h",
            yanchor="bottom",
            y=1.02,
            x=0
        )
    )

    st.plotly_chart(
        fig_evolucion,
        width="stretch",
        key="leads_evolucion"
    )

with col_embudo:
    st.subheader("¿Cuántos leads llegan a convertirse en ventas?")

    tabla_embudo = pd.DataFrame({
        "Etapa": [
            "Total leads",
            "Leads efectivos",
            "Ventas"
        ],
        "Cantidad": [
            total_leads,
            total_efectivos,
            total_ventas
        ]
    })

    porcentajes_embudo = (
        tabla_embudo["Cantidad"] / total_leads * 100
    )

    etiquetas_embudo = [
        f"{cantidad:,.0f}<br>{porcentaje:.1f}%"
        for cantidad, porcentaje in zip(
            tabla_embudo["Cantidad"],
            porcentajes_embudo
        )
    ]

    fig_embudo = go.Figure(
        go.Funnel(
            y=tabla_embudo["Etapa"],
            x=tabla_embudo["Cantidad"],
            text=etiquetas_embudo,
            textinfo="text",
            textposition="auto",
            marker=dict(
                color=["#F2C5CA", "#B53B4E", "#D71920"]
            ),
            customdata=porcentajes_embudo.to_numpy(),
            hovertemplate=(
                "%{y}<br>"
                "Cantidad: %{x:,.0f}<br>"
                "Del total de leads: %{customdata:.1f}%"
                "<extra></extra>"
            )
        )
    )

    st.plotly_chart(
        ajustar_figura(fig_embudo),
        width="stretch",
        key="leads_embudo"
    )

# Fila 2: calidad y conversión por mes
col_calidad, col_conversion = st.columns(2)

with col_calidad:
    st.subheader("¿Cómo se distribuye la calidad de los leads?")
    st.caption(
        "Porcentajes sobre la suma de las cinco categorías de cada mes."
    )

    calidad = data_f[CATEGORIAS].div(
        data_f["Suma_Cat"].where(data_f["Suma_Cat"].gt(0)),
        axis=0
    ) * 100

    calidad["Periodo"] = data_f["Periodo"]

    tabla_calidad = calidad.melt(
        id_vars="Periodo",
        var_name="Categoría",
        value_name="Porcentaje"
    )

    tabla_calidad["Categoría"] = (
        tabla_calidad["Categoría"].map(ETIQUETAS)
    )

    fig_calidad = px.bar(
        tabla_calidad,
        x="Periodo",
        y="Porcentaje",
        color="Categoría",
        color_discrete_map=COLORES_CALIDAD,
        category_orders={
            "Periodo": data_f["Periodo"].tolist(),
            "Categoría": list(ETIQUETAS.values())
        }
    )

    fig_calidad.update_traces(
        hovertemplate=(
            "%{x}<br>"
            "Porcentaje: %{y:.1f}%"
            "<extra>%{fullData.name}</extra>"
        )
    )

    fig_calidad.update_xaxes(
        title=None,
        tickangle=-45,
        automargin=True
    )

    fig_calidad.update_yaxes(
        title="Porcentaje de categorías",
        ticksuffix="%",
        range=[0, 100]
    )

    ajustar_figura(
        fig_calidad,
        altura=310,
        leyenda=True
    )

    fig_calidad.update_layout(
        barmode="stack",
        legend=dict(
            title=None,
            orientation="h",
            yanchor="top",
            y=-0.3,
            xanchor="center",
            x=0.5,
            font=dict(size=10)
        )
    )

    st.plotly_chart(
        fig_calidad,
        width="stretch",
        key="leads_calidad"
    )

with col_conversion:
    st.subheader("¿Qué meses tienen mayor conversión?")
    st.caption("Ventas como porcentaje de los leads efectivos.")

    tabla_conversion = data_f.pivot(
        index="Año",
        columns="Mes",
        values="Conv_Efectivos"
    )

    tabla_conversion = tabla_conversion.reindex(
        index=sorted(data_f["Año"].unique()),
        columns=sorted(data_f["Mes"].unique())
    )

    tabla_conversion.index = (
        tabla_conversion.index.astype(str)
    )

    tabla_conversion.columns = [
        MESES[mes] for mes in tabla_conversion.columns
    ]

    fig_conversion = px.imshow(
        tabla_conversion,
        text_auto=".1f",
        aspect="auto",
        color_continuous_scale=ESCALA_VINO,
        labels={
            "x": "Mes",
            "y": "Año",
            "color": "Conversión (%)"
        }
    )

    fig_conversion.update_traces(
        hoverongaps=False,
        hovertemplate=(
            "Año: %{y}<br>"
            "Mes: %{x}<br>"
            "Conversión: %{z:.1f}%"
            "<extra></extra>"
        )
    )

    fig_conversion.update_xaxes(title=None)

    fig_conversion.update_yaxes(
        title=None,
        type="category"
    )

    st.plotly_chart(
        ajustar_figura(fig_conversion, altura=310),
        width="stretch",
        key="leads_conversion"
    )