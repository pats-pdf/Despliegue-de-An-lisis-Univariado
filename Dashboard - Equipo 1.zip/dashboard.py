import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
from pathlib import Path

st.set_page_config(
    page_title="GAC | Vista general",
    page_icon="🚗",
    layout="wide"
)

# dashboard.py está fuera de pages
CARPETA_BASE = Path(__file__).resolve().parent

COLORES_PRODUCTOS = {
    "EMZOOM": "#D71920",
    "EMKOO": "#750015",
    "GS8": "#F59CA5",
    "AION": "#B53B4E",
    "GN8": "#963444",
    "GS4": "#F2C5CA",
    "NO REGISTRADO": "#C7C7C7"
}

COLORES_ESTATUS = {
    "Activo": "#0072B2",
    "Cerrado": "#F28E2B",
    "Venta": "#009E73",
    "Finalizado": "#E9B824",
    "No registrado": "#C7C7C7"
}

ESCALA_VINO = [
    "#FAF7F7",
    "#F2C5CA",
    "#E89AA4",
    "#D46573",
    "#B53B4E",
    "#7A1F2B",
    "#4A101A"
]


@st.cache_data
def leer_csv(nombre):
    rutas = [
        CARPETA_BASE / nombre,
        CARPETA_BASE / "data" / nombre
    ]

    ruta = next(
        (ruta for ruta in rutas if ruta.exists()),
        None
    )

    if ruta is None:
        raise FileNotFoundError(
            f"No se encontró {nombre}."
        )

    df = pd.read_csv(ruta)
    df.columns = df.columns.str.strip()
    return df


def limpiar_texto(df, columnas):
    df = df.copy()

    for columna in columnas:
        df[columna] = (
            df[columna]
            .astype("string")
            .str.strip()
            .replace("", pd.NA)
            .fillna("No registrado")
        )

    return df


def arreglar_texto(texto):
    if not isinstance(texto, str):
        return texto

    for codificacion in ("cp1252", "latin-1"):
        try:
            texto = texto.encode(codificacion).decode("utf-8")
            break
        except (UnicodeEncodeError, UnicodeDecodeError):
            continue

    return " ".join(texto.split())


def normalizar(serie):
    return (
        serie.astype("string")
        .str.strip()
        .str.casefold()
    )


def porcentaje(cantidad, total):
    return cantidad / total * 100 if total > 0 else 0


def ajustar_figura(figura, altura=270, leyenda=False):
    figura.update_layout(
        height=altura,
        showlegend=leyenda,
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        margin=dict(l=10, r=35, t=15, b=35),
        font=dict(size=12)
    )

    return figura


def enlace(archivo, etiqueta):
    if (CARPETA_BASE / "pages" / archivo).exists():
        st.page_link(
            f"pages/{archivo}",
            label=etiqueta
        )


def grafica_barras(tabla, categoria, colores=None):
    tabla = tabla.sort_values("Cantidad").copy()

    tabla["Etiqueta"] = tabla["Cantidad"].map(
        lambda valor: f"{valor:,.0f}"
    )

    argumentos = {
        "data_frame": tabla,
        "x": "Cantidad",
        "y": categoria,
        "orientation": "h",
        "text": "Etiqueta"
    }

    if colores is not None:
        argumentos["color"] = categoria
        argumentos["color_discrete_map"] = colores
    else:
        argumentos["color_discrete_sequence"] = ["#B53B4E"]

    figura = px.bar(**argumentos)

    figura.update_traces(
        textposition="outside",
        cliponaxis=False,
        hovertemplate=(
            "%{y}<br>"
            "Registros: %{x:,.0f}"
            "<extra></extra>"
        )
    )

    figura.update_xaxes(
        title="Número de registros",
        range=[0, tabla["Cantidad"].max() * 1.18]
    )

    figura.update_yaxes(
        title=None,
        categoryorder="array",
        categoryarray=tabla[categoria].tolist(),
        automargin=True
    )

    return ajustar_figura(figura)


# Encabezado
col_logo, col_titulo = st.columns([1, 5])

with col_logo:
    st.image(
        str(CARPETA_BASE / "logo_gac.png"),
        width=150
    )

with col_titulo:
    st.title("GAC | Vista general")
    st.caption(
        "Captación, atención comercial y resultados "
        "de las cinco bases del equipo"
    )

st.markdown(
    """
    <div style="
        height:4px;
        background:#D71920;
        border-radius:4px;
        margin-bottom:20px;
    "></div>
    <style>
    div[data-testid="stMetric"] {
        background: rgba(117,0,21,0.22);
        border: 1px solid rgba(215,25,32,0.25);
        border-radius: 12px;
        padding: 12px 14px;
    }

    div[data-testid="stMetricValue"] {
        font-size: 28px;
    }
    </style>
    """,
    unsafe_allow_html=True
)

st.sidebar.title("🚗 GAC | Vista general")
st.sidebar.caption(
    "Esta vista muestra el conjunto completo de cada base. "
    "Abre las páginas de detalle para aplicar sus filtros."
)

st.caption(
    "Cada bloque corresponde a una base distinta. "
    "Los registros pueden coincidir entre bases y sus totales "
    "no se suman."
)

# 1. VENTAS Y CONVERSIÓN
with st.container(border=True):
    st.subheader("📊 Ventas y conversión")

    leads = leer_csv("base leads.csv")

    for columna in ["Año", "Mes", "Total", "Efectivos", "Ventas"]:
        leads[columna] = pd.to_numeric(
            leads[columna],
            errors="coerce"
        )

    leads["Fecha"] = pd.to_datetime(
        {
            "year": leads["Año"],
            "month": leads["Mes"],
            "day": 1
        },
        errors="coerce"
    )

    leads = leads[
        leads["Fecha"].notna()
        & leads["Total"].gt(0)
    ].copy()

    if leads.empty:
        st.info("No hay meses con leads disponibles.")
    else:
        mensual = (
            leads.groupby("Fecha", as_index=False)[
                ["Total", "Efectivos", "Ventas"]
            ]
            .sum(min_count=1)
            .sort_values("Fecha")
        )

        total = mensual["Total"].sum()
        efectivos = mensual["Efectivos"].sum()
        ventas = mensual["Ventas"].sum()

        conversion = (
            ventas / efectivos * 100
            if efectivos > 0 else None
        )

        mensual["Conversión"] = (
            mensual["Ventas"].div(
                mensual["Efectivos"].where(
                    mensual["Efectivos"].gt(0)
                )
            ) * 100
        )

        st.caption(
            "Fuente: histórico de Leads · "
            f"{mensual['Fecha'].min():%m/%Y} – "
            f"{mensual['Fecha'].max():%m/%Y}"
        )

        c1, c2, c3, c4 = st.columns(4)

        c1.metric("Leads totales", f"{total:,.0f}")
        c2.metric("Leads efectivos", f"{efectivos:,.0f}")
        c3.metric("Ventas", f"{ventas:,.0f}")
        c4.metric(
            "Conversión de efectivos",
            f"{conversion:.1f}%" if conversion is not None else "—"
        )

        st.caption(
            f"Efectivos: {porcentaje(efectivos, total):.1f}% "
            f"del total · Ventas: {porcentaje(ventas, total):.1f}% "
            "del total"
        )

        figura = make_subplots(
            specs=[[{"secondary_y": True}]]
        )

        figura.add_trace(
            go.Bar(
                x=mensual["Fecha"],
                y=mensual["Ventas"],
                name="Ventas",
                marker_color="#D71920",
                hovertemplate=(
                    "%{x|%m/%Y}<br>"
                    "Ventas: %{y:,.0f}"
                    "<extra></extra>"
                )
            ),
            secondary_y=False
        )

        figura.add_trace(
            go.Scatter(
                x=mensual["Fecha"],
                y=mensual["Conversión"],
                name="Conversión de efectivos",
                mode="lines+markers",
                line=dict(color="#F2C5CA", width=2),
                connectgaps=False,
                hovertemplate=(
                    "%{x|%m/%Y}<br>"
                    "Conversión: %{y:.1f}%"
                    "<extra></extra>"
                )
            ),
            secondary_y=True
        )

        figura.update_yaxes(
            title_text="Ventas",
            rangemode="tozero",
            secondary_y=False
        )

        figura.update_yaxes(
            title_text="Conversión de efectivos",
            ticksuffix="%",
            tickformat=".1f",
            rangemode="tozero",
            secondary_y=True
        )

        figura.update_xaxes(tickformat="%m/%Y")

        ajustar_figura(figura, altura=260, leyenda=True)

        figura.update_layout(
            legend=dict(
                orientation="h",
                yanchor="bottom",
                y=1.02,
                x=0
            )
        )

        st.plotly_chart(
            figura,
            width="stretch",
            key="general_ventas"
        )

    enlace("5_Leads.py", "Abrir ventas y conversión")


# Fila 2: Bitácora y Tlaxcala
col_bitacora, col_tlaxcala = st.columns(2)

# 2. BITÁCORA DE PISO
with col_bitacora:
    with st.container(border=True):
        st.subheader("🚗 Bitácora de Piso")
        st.caption("Fuente: Bitácora de Piso · Base completa")

        piso = leer_csv("Bitacora_Piso_Limpia.csv")

        piso = piso.rename(columns={
            "PDM": "Prueba de manejo",
            "Inter Gerente": "Intervención del gerente"
        })

        piso = limpiar_texto(
            piso,
            [
                "Estatus Lead",
                "Prueba de manejo",
                "Intervención del gerente"
            ]
        )

        total_piso = len(piso)

        if total_piso == 0:
            st.info("No hay registros disponibles.")
        else:
            pdm = int(
                normalizar(piso["Prueba de manejo"])
                .isin(["sí", "si"])
                .sum()
            )

            gerente = int(
                normalizar(piso["Intervención del gerente"])
                .isin(["sí", "si"])
                .sum()
            )

            c1, c2, c3 = st.columns(3)

            c1.metric("Registros", f"{total_piso:,}")
            c2.metric(
                "Prueba de manejo",
                f"{porcentaje(pdm, total_piso):.1f}%"
            )
            c3.metric(
                "Intervención gerente",
                f"{porcentaje(gerente, total_piso):.1f}%"
            )

            st.caption(
                f"Prueba de manejo: {pdm:,} registros · "
                f"Intervención del gerente: {gerente:,} registros"
            )

            tabla = (
                piso["Estatus Lead"]
                .value_counts()
                .rename_axis("Estatus")
                .reset_index(name="Cantidad")
            )

            st.markdown("**¿En qué estatus están los prospectos?**")

            st.plotly_chart(
                grafica_barras(
                    tabla,
                    "Estatus",
                    COLORES_ESTATUS
                ),
                width="stretch",
                key="general_piso"
            )

        enlace(
            "1_Bitacora_de_Piso.py",
            "Abrir Bitácora de Piso"
        )


# 3. TLAXCALA
with col_tlaxcala:
    with st.container(border=True):
        st.subheader("📍 Tlaxcala")
        st.caption("Fuente: Tlaxcala · Base completa")

        tlaxcala = limpiar_texto(
            leer_csv("Base_de_Tlaxcala.csv"),
            ["Producto", "Temperatura", "Estatus"]
        )

        total_tlaxcala = len(tlaxcala)

        if total_tlaxcala == 0:
            st.info("No hay registros disponibles.")
        else:
            temperatura = normalizar(tlaxcala["Temperatura"])
            estatus = normalizar(tlaxcala["Estatus"])

            interesados = int(
                temperatura.eq("lead muy interesado").sum()
            )
            contactados = int(estatus.eq("contactado").sum())
            finalizados = int(estatus.eq("finalizado").sum())

            c1, c2, c3, c4 = st.columns(4)

            c1.metric("Leads", f"{total_tlaxcala:,}")
            c2.metric("Muy interesados", f"{interesados:,}")
            c3.metric("Contactados", f"{contactados:,}")
            c4.metric("Finalizados", f"{finalizados:,}")

            st.caption(
                f"Muy interesados: "
                f"{porcentaje(interesados, total_tlaxcala):.1f}% · "
                f"Contactados: "
                f"{porcentaje(contactados, total_tlaxcala):.1f}% · "
                f"Finalizados: "
                f"{porcentaje(finalizados, total_tlaxcala):.1f}%"
            )

            tabla = (
                tlaxcala["Producto"]
                .str.upper()
                .value_counts()
                .rename_axis("Producto")
                .reset_index(name="Cantidad")
            )

            st.markdown("**¿Qué productos generan más interés?**")

            st.plotly_chart(
                grafica_barras(
                    tabla,
                    "Producto",
                    COLORES_PRODUCTOS
                ),
                width="stretch",
                key="general_tlaxcala"
            )

        enlace("2_Tlaxcala.py", "Abrir Tlaxcala")


# Fila 3: Citas Digital y Plazas
col_citas, col_plazas = st.columns(2)

# 4. CITAS DIGITAL
with col_citas:
    with st.container(border=True):
        st.subheader("📅 Citas Digital")

        citas = limpiar_texto(
            leer_csv("GAC_CitasDigital_Looker_FINAL.csv"),
            ["bdc", "estatus_lead"]
        )

        citas["bdc"] = citas["bdc"].replace({
            "Igancio": "Ignacio"
        })

        citas["fecha"] = pd.to_datetime(
            citas["fecha"],
            format="%m/%d/%Y",
            errors="coerce"
        )

        sin_fecha = int(citas["fecha"].isna().sum())

        # Mismo alcance que la vista de detalle por defecto
        citas = citas[citas["fecha"].notna()].copy()

        total_citas = len(citas)

        if total_citas == 0:
            st.info("No hay registros con fecha válida.")
        else:
            st.caption(
                "Fuente: Citas Digital · "
                f"{citas['fecha'].min():%d/%m/%Y} – "
                f"{citas['fecha'].max():%d/%m/%Y}"
            )

            estatus = normalizar(citas["estatus_lead"])

            activos = int(estatus.eq("activo").sum())
            ventas_citas = int(
                estatus.isin(["venta", "ventas"]).sum()
            )
            finalizados = int(estatus.eq("finalizado").sum())

            c1, c2, c3, c4 = st.columns(4)

            c1.metric("Leads", f"{total_citas:,}")
            c2.metric("Activos", f"{activos:,}")
            c3.metric("Ventas", f"{ventas_citas:,}")
            c4.metric("Finalizados", f"{finalizados:,}")

            st.caption(
                f"Activos: {porcentaje(activos, total_citas):.1f}% · "
                f"Ventas: {porcentaje(ventas_citas, total_citas):.1f}% · "
                f"Finalizados: "
                f"{porcentaje(finalizados, total_citas):.1f}%"
            )

            tabla = pd.crosstab(
                citas["bdc"],
                citas["estatus_lead"]
            )

            tabla = tabla.loc[
                tabla.sum(axis=1)
                .sort_values(ascending=False)
                .index
            ]

            porcentajes = (
                tabla.div(tabla.sum(axis=1), axis=0) * 100
            )

            etiquetas = [
                [
                    f"{tabla.iloc[i, j]:,}"
                    f"<br>{porcentajes.iloc[i, j]:.1f}%"
                    for j in range(tabla.shape[1])
                ]
                for i in range(tabla.shape[0])
            ]

            st.markdown(
                "**¿En qué estatus están los leads de cada BDC?**"
            )

            figura = go.Figure(
                go.Heatmap(
                    z=tabla.to_numpy(),
                    x=tabla.columns.tolist(),
                    y=tabla.index.tolist(),
                    text=etiquetas,
                    texttemplate="%{text}",
                    customdata=porcentajes.to_numpy(),
                    colorscale=ESCALA_VINO,
                    zmin=0,
                    xgap=2,
                    ygap=2,
                    colorbar=dict(
                        title="Leads",
                        thickness=10
                    ),
                    hovertemplate=(
                        "BDC: %{y}<br>"
                        "Estatus: %{x}<br>"
                        "Leads: %{z}<br>"
                        "Dentro del BDC: %{customdata:.1f}%"
                        "<extra></extra>"
                    )
                )
            )

            figura.update_yaxes(
                autorange="reversed",
                automargin=True
            )

            st.plotly_chart(
                ajustar_figura(figura, altura=290),
                width="stretch",
                key="general_citas"
            )

        if sin_fecha:
            st.caption(
                f"Se excluyen {sin_fecha:,} registros sin fecha válida."
            )

        enlace("3_Citas_Digital.py", "Abrir Citas Digital")


# 5. PLAZAS
with col_plazas:
    with st.container(border=True):
        st.subheader("🏬 Plazas")

        plazas = leer_csv("Plazas_sin_nulos.csv")

        for columna in ["Producto", "Origen"]:
            plazas[columna] = plazas[columna].map(arreglar_texto)

        plazas = limpiar_texto(
            plazas,
            ["Producto", "Origen"]
        )

        plazas["Producto"] = plazas["Producto"].str.upper()
        plazas["Origen"] = plazas["Origen"].str.title()

        plazas["Fecha Origen"] = pd.to_datetime(
            plazas["Fecha Origen"],
            errors="coerce"
        )

        sin_fecha = int(plazas["Fecha Origen"].isna().sum())

        # Mismo alcance que la página con filtro de hora
        plazas = plazas[
            plazas["Fecha Origen"].notna()
        ].copy()

        plazas["Seguimiento"] = pd.to_numeric(
            plazas["Seguimiento"],
            errors="coerce"
        )

        total_plazas = len(plazas)

        if total_plazas == 0:
            st.info("No hay registros con fecha válida.")
        else:
            st.caption(
                "Fuente: Plazas · "
                f"{plazas['Fecha Origen'].min():%d/%m/%Y} – "
                f"{plazas['Fecha Origen'].max():%d/%m/%Y}"
            )

            seguimiento = int(
                plazas["Seguimiento"].eq(1).sum()
            )

            productos_validos = plazas.loc[
                plazas["Producto"] != "NO REGISTRADO",
                "Producto"
            ]

            conteo_productos = productos_validos.value_counts()

            producto_lider = (
                str(conteo_productos.index[0])
                if not conteo_productos.empty
                else "Sin dato"
            )

            c1, c2, c3 = st.columns(3)

            c1.metric("Leads", f"{total_plazas:,}")
            c2.metric(
                "Con seguimiento",
                f"{porcentaje(seguimiento, total_plazas):.1f}%"
            )
            c3.metric("Producto líder", producto_lider)

            st.caption(
                f"Con seguimiento: {seguimiento:,} "
                f"de {total_plazas:,} leads"
            )

            tabla = (
                plazas["Origen"]
                .value_counts()
                .rename_axis("Plaza")
                .reset_index(name="Cantidad")
            )

            colores_plazas = {
                "Galerias Tlaxcala": "#F59CA5",
                "Gran Patio Tlaxcala": "#B53B4E",
                "Plaza Angelopolis": "#D71920"
            }

            st.markdown("**¿Qué plazas captan más leads?**")

            st.plotly_chart(
                grafica_barras(
                    tabla,
                    "Plaza",
                    colores_plazas
                ),
                width="stretch",
                key="general_plazas"
            )

        if sin_fecha:
            st.caption(
                f"Se excluyen {sin_fecha:,} registros sin fecha válida."
            )

        enlace("4_Plazas.py", "Abrir Plazas")